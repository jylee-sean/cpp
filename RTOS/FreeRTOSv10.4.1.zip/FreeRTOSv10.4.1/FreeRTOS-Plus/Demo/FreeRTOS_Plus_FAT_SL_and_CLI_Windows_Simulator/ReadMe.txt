This demo was removed in FreeRTOS V10.0.0 as FreeRTOS+FAT SL was not distributed
in that release.  The full FreeRTOS+FAT product (as opposed to the 'SL' Super
Lean product) is still available.  Previous versions of FreeRTOS can be
downloaded from http://sourceforge.net/projects/freertos/files/FreeRTOS/



