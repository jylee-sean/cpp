FreeRTOS+UDP was removed in FreeRTOS V10.1.0 as it was replaced by FreeRTOS+TCP,
which was brought into the main download in FreeRTOS V10.0.0.  FreeRTOS+TCP can
be configured as a UDP only stack, and FreeRTOS+UDP does not contain the patches
applied to FreeRTOS+TCP.